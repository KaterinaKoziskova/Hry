function startPexeso() {
    const gameBoard = createGameBoard(10);
    const revealedCards = [];
    let pairsFound = 0;
  
    function createGameBoard(size) {
      const cards = [];
      for (let i = 1; i <= size / 2; i++) {
        cards.push(i);
        cards.push(i);
      }
      shuffle(cards);
      return cards;
    }
  
    function shuffle(array) {
      for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
      }
    }
  
    function renderBoard() {
      const pexesoGame = document.getElementById('pexeso-game');
      pexesoGame.innerHTML = '';
  
      for (let i = 0; i < gameBoard.length; i++) {
        const cardElement = document.createElement('div');
        cardElement.className = 'card';
        cardElement.textContent = '⭐';
        cardElement.onclick = () => revealCard(i);
        pexesoGame.appendChild(cardElement);
      }
    }
  
    function revealCard(index) {
      const cardElement = document.getElementById('pexeso-game').children[index];
  
      if (revealedCards.length < 2 && !revealedCards.includes(index)) {
        cardElement.textContent = gameBoard[index];
        revealedCards.push(index);
      }
  
      if (revealedCards.length === 2) {
        setTimeout(() => checkMatch(), 1000);
      }
    }
  
    function checkMatch() {
      const [card1, card2] = revealedCards;
  
      if (gameBoard[card1] === gameBoard[card2]) {
        console.log('Gratulujeme, našli jste pár!');
        pairsFound++;
        document.getElementById('score').textContent = 'Pairs found: ' + pairsFound;
  
        if (pairsFound === gameBoard.length / 2) {
          console.log('Vyhrál jsi!');
        }
      } else {
        console.log('Bohužel, karty se neshodují. Zkuste to znovu.');
        hideCards();
      }
  
      revealedCards.length = 0;
    }
  
    function hideCards() {
      revealedCards.forEach(cardIndex => {
        const cardElement = document.getElementById('pexeso-game').children[cardIndex];
        cardElement.textContent = '⭐';
      });
    }
  
    renderBoard();
  }
  
  window.onload = startPexeso;
  