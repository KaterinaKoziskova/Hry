document.addEventListener("DOMContentLoaded", function () {
  const playButton = document.getElementById("playButton");
  const sudokuContainer = document.getElementById("sudokuContainer");

  playButton.addEventListener("click", startSudokuGame);

  function startSudokuGame() {
    clearSudokuContainer();
    const sudokuGrid = generateSudokuPuzzle();
    displaySudokuGrid(sudokuGrid);
    enableUserInteraction(sudokuGrid);
  }

  function clearSudokuContainer() {
    sudokuContainer.innerHTML = "";
  }

  function generateSudokuPuzzle() {
    return [
      [5, 3, 0, 0, 7, 0, 0, 0, 0],
      [6, 0, 0, 1, 9, 5, 0, 0, 0],
      [0, 9, 8, 0, 0, 0, 0, 6, 0],
      [8, 0, 0, 0, 6, 0, 0, 0, 3],
      [4, 0, 0, 8, 0, 3, 0, 0, 1],
      [7, 0, 0, 0, 2, 0, 0, 0, 6],
      [0, 6, 0, 0, 0, 0, 2, 8, 0],
      [0, 0, 0, 4, 1, 9, 0, 0, 5],
      [0, 0, 0, 0, 8, 0, 0, 7, 9]
    ];
  }

  function displaySudokuGrid(grid) {
    const table = document.createElement("table");
    table.classList.add("sudoku-grid");

    grid.forEach((row) => {
      const tr = document.createElement("tr");
      row.forEach((cell) => {
        const td = document.createElement("td");
        td.textContent = cell || "";
        td.contentEditable = cell ? "false" : "true";
        tr.appendChild(td);
      });
      table.appendChild(tr);
    });

    sudokuContainer.appendChild(table);
  }

  function enableUserInteraction(grid) {
    sudokuContainer.innerHTML += "<p>Try to solve the Sudoku!</p>";
    const cells = document.querySelectorAll(".sudoku-grid td");

    cells.forEach((cell) => {
      cell.addEventListener("input", function () {
        const value = parseInt(this.textContent) || 0;
        const row = this.parentElement.rowIndex;
        const col = this.cellIndex;

        if (isValidMove(grid, row, col, value)) {
          grid[row][col] = value;
        } else {
          this.textContent = "";
        }

        if (isSolved(grid)) {
          sudokuContainer.innerHTML += "<p>Congratulations! You solved the Sudoku!</p>";
        }
      });
    });
  }

  function isValidMove(grid, row, col, value) {
    return true;
  }

  function isSolved(grid) {
    return grid.every(row => row.every(cell => cell !== 0));
  }
});
